"use strict";

const fs = require("fs");
const path = require("path");

let mode = "memory";
let pool = null;
let filePath = null;

async function initPersistence() {
  if (process.env.DATABASE_URL) {
    const { Pool } = require("pg");
    pool = new Pool({
      connectionString: process.env.DATABASE_URL,
      ssl: process.env.PGSSLMODE === "disable" ? false : { rejectUnauthorized: false },
      max: 5,
      idleTimeoutMillis: 30000,
      connectionTimeoutMillis: 10000,
    });
    await pool.query(`
      CREATE TABLE IF NOT EXISTS parau_rooms (
        code VARCHAR(8) PRIMARY KEY,
        room_json JSONB NOT NULL,
        updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
      )
    `);
    mode = "postgres";
    return mode;
  }

  if (process.env.PERSIST_FILE) {
    filePath = path.resolve(process.env.PERSIST_FILE);
    fs.mkdirSync(path.dirname(filePath), { recursive: true });
    mode = "file";
  }
  return mode;
}

async function loadRooms() {
  if (mode === "postgres") {
    const result = await pool.query(
      `SELECT room_json FROM parau_rooms WHERE updated_at > NOW() - INTERVAL '7 days'`
    );
    return result.rows.map(r => r.room_json);
  }
  if (mode === "file") {
    try {
      const raw = await fs.promises.readFile(filePath, "utf8");
      const list = JSON.parse(raw);
      return Array.isArray(list) ? list : [];
    } catch (e) {
      if (e.code !== "ENOENT") console.warn("Falha ao ler persistência em arquivo:", e.message);
      return [];
    }
  }
  return [];
}

async function saveRoom(room) {
  if (!room || !room.code) return;
  if (mode === "postgres") {
    await pool.query(
      `INSERT INTO parau_rooms(code, room_json, updated_at)
       VALUES($1, $2::jsonb, NOW())
       ON CONFLICT(code) DO UPDATE SET room_json = EXCLUDED.room_json, updated_at = NOW()`,
      [room.code, JSON.stringify(room)]
    );
  }
}

async function saveAllRooms(rooms) {
  if (mode !== "file") return;
  const temp = filePath + ".tmp";
  await fs.promises.writeFile(temp, JSON.stringify([...rooms.values()], null, 2), "utf8");
  await fs.promises.rename(temp, filePath);
}

async function deleteRoom(code) {
  if (mode === "postgres") {
    await pool.query(`DELETE FROM parau_rooms WHERE code=$1`, [code]);
  }
}

async function cleanupExpired(days = 7) {
  if (mode === "postgres") {
    await pool.query(`DELETE FROM parau_rooms WHERE updated_at < NOW() - ($1 * INTERVAL '1 day')`, [days]);
  }
}

function getPersistenceMode() { return mode; }

module.exports = { initPersistence, loadRooms, saveRoom, saveAllRooms, deleteRoom, cleanupExpired, getPersistenceMode };
